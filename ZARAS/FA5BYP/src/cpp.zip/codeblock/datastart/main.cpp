#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ofstream myfileout;
    ifstream myfilein;
    myfileout.open("kiadat3.txt");
    myfilein.open("kiadat.txt");
    string myline;
    char currentchar;
    while(!myfilein.eof())
    {
        getline(myfilein,myline);
        /*
        ezzel sz�tt�rdel�s sorokra:
        for(unsigned int i=0;i<=myline.length();i++)
        {
            currentchar = myline[i];
            if(currentchar == ',')
            {
                myfileout <<"\n";
            } else {
                myfileout << currentchar;
            }
        }
        */
        int k = 0;
        currentchar = myline[k];
        while(currentchar != '_')
        {
            currentchar = myline[k];
            k++;
        }
        for(int i = k;i<myline.length();i++)
        {
            myfileout << myline[i];
        }
        myfileout <<"_";
        k=0;
        currentchar = myline[k];
        while(currentchar != '_')
        {
            myfileout <<currentchar;
            k++;
            currentchar = myline[k];
        }
        myfileout<<",";
    }
    myfileout.close();
    myfilein.close();
    return 0;
}
