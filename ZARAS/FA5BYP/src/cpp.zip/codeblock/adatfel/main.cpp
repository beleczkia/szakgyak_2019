#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    ofstream myfileout;
    ifstream myfilein;
    myfileout.open("kiadat3.txt");
    myfilein.open("kiadat.txt");
    string myline;
    char currentchar;
    while(!myfilein.eof())
    {
        getline(myfilein,myline);
        int k = 0;
        currentchar = myline[k];
        while(currentchar != '\n')
        {
            myfileout <<currentchar;
            k++;
            currentchar = myline[k];
        }
        myfileout<<',';
    }
    myfileout.close();
    myfilein.close();
    return 0;
}
