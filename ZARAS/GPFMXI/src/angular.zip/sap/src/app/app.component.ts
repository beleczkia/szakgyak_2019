//import { Component, OnInit, OnChanges } from '@angular/core';
import { Component, OnInit} from '@angular/core';
import * as CanvasJS from 'canvasjs/canvasjs.min';
import { OdataService } from './services/odata.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

//export class AppComponent implements OnInit, OnChanges {
export class AppComponent implements OnInit {
	title = 'GPFMXI nyárigyak';
	years: any = [];
	regios: any = [];
	year;
	regio;
	data;

	constructor(private odata: OdataService) { }

	ngOnInit() {
		
		this.year = 2017;
		this.regio = 'Dél-Alföld régió';
		
		this.odata.getData('/kalkulacio?$select=ASZ_EVE').subscribe((res: any) => {
			for(let i = 0; i < res.d.results.length; ++i)
			{
				this.years[i] = res.d.results[i].ASZ_EVE;
				console.log(this.year[i]);
				console.log(res.d.results[i]);
			}
		});
		
		this.odata.getData('/kalkulacio?$select=REGIO').subscribe((res: any) => {
			for(let i = 0; i < res.d.results.length; ++i)
			{
				this.regios[i] = res.d.results[i].REGIO;
				console.log(this.regio[i]);
				console.log(res.d.results[i]);
			}
		});
		
		this.odata.getData('DATABASE?$top=1000&$orderby=JEGYZ_TOKE_ERT_HUF+desc').subscribe((res: any) => {
		this.data = res.d.results;
		show_graph(this.data);
		
    });

    function show_graph(db) {
		
		var array = [];
		for (var i = 0; i < db.length; ++i) {
			array.push({ label: db[i].TARS_ROV_NEV, y: db[i].JEGYZ_TOKE_ERT_HUF / 1000000 })
		}
		console.log(db[0].TARS_ROV_NEV);

		var chart = new CanvasJS.Chart("chartContainer",
        {
			animationEnabled: true,
			exportEnabled: true,
			title: {
				text: "Cégek vagyona /millió forint",
				fontSize: 20
			},

			data: [
            {
				type: "column",
				indexLabelPlacement: "outside",
				indexLabelOrientation: "horizontal",
				dataPoints: array
            }
			]
        });

		chart.render();
		}
	}
  
	onChange(val) {
		
		if (isNaN(val)){
			this.regio = val;
		}
		else{
			this.year = val;
		}
		
		var curryear = this.year;
		var currregio = this.regio;
		var db = this.data;

		var newdb = db.filter(function (db) {
			return db.ASZ_EVE == curryear && db.REGIO == currregio;
		});

		var arr = [];

		for (var i = 0; i < newdb.length; ++i) {
			arr.push({ label: newdb[i].TARS_ROV_NEV, y: newdb[i].JEGYZ_TOKE_ERT_HUF / 1000000 })
		}

		var chart = new CanvasJS.Chart("chartContainer",
		{
			animationEnabled: true,
			exportEnabled: true,
			title: {
				text: "Cégek vagyona /millió forint",
				fontSize: 20
			},

			data: [
			{
				type: "column",
				indexLabelPlacement: "outside",
				indexLabelOrientation: "horizontal",
				dataPoints: arr
			}
			]
		});
		chart.render();
	}
}



