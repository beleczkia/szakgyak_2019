![My image](https://github.com/MicroKiss/GISLab/blob/master/src/assets/5Pikachu.png)

Angular version 8.1.0.

## How to start

npm install to get node packages and then `ng serve` or`npm start`. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## create new thingies:
Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

NO TESTS

## Further help

Ask mcserep
