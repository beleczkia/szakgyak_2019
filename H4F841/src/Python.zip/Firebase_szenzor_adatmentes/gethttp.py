import urllib2
contents = urllib2.urlopen("http://192.168.1.4/meteograph.cgi?text=actual_th0_hum_rel").read()

print contents
