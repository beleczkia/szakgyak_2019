#!/usr/bin/env python
# -*- coding:Utf-8 -*-

import os
import re
import time
import tosr0x
import math
import serial
import sys

def main():

    def currtemp():
        while True:
            try:
                temperature = False
                while temperature == False:
                   sd=serial.Serial('/dev/medence', timeout=0.1)
                   myTosr0x=tosr0x.relayModule(sd, relayCount=2)
                   temperature = float(myTosr0x.get_temperature())
                break
            except:
                time.sleep(0.1)
        return temperature

    from firebase import firebase
    firebase= firebase.FirebaseApplication('https://tempdata-4be31.firebaseio.com', None)
    while True:

        now = time.localtime(time.time())
        localtime = time.strftime("%y/%m/%d %H:%M:%S", now)
        result = firebase.post('tempdata-4be31', {'Time':str(localtime),'Temp':str(currtemp())})
	time.sleep(30)

if __name__ == '__main__':
	main()
