#!/usr/bin/env python
# -*- coding:Utf-8 -*-

import os
import re
import time
import math
import urllib2
import sys
import json


def main():

	def jdata():
		data = urllib2.urlopen("https://tempdata-4be31.firebaseio.com/Adatmentes.json").read()
		return data

	def maxtemp():
		readable = json.loads(jdata())
		maxtemp = -500
		for i in readable:
			if readable[i]['Temp'] > maxtemp:
				maxtemp = readable[i]['Temp']
		return maxtemp

	def maxhum():
                readable = json.loads(jdata())
                maxhum = -1
                for i in readable:
                        if readable[i]['Hum'] > maxhum:
                                maxhum = readable[i]['Hum']
                return maxhum	

	def mintemp():
                readable = json.loads(jdata())
                mintemp = 35.0
		for i in readable:
			mintemp = readable[i]['Temp']
			break
                for i in readable:
                        if mintemp > readable[i]['Temp']:
                                mintemp = readable[i]['Temp']
                return mintemp

	def minhum():
                readable = json.loads(jdata())
                minhum = 101
		for i in readable:
                        minhum = readable[i]['Hum']
                for i in readable:
                        if readable[i]['Hum'] < minhum:
                                minhum = readable[i]['Hum']
                return minhum
	def avgtemp():
		readable = json.loads(jdata())
		sum = 0.0
		count = 0
		for i in readable:
			count += 1
			sum += float(readable[i]['Temp'])
		avg = sum / count
		return avg
	def avghum():
		readable = json.loads(jdata())
                sum = 0
                count = 0
                for i in readable:
                        count += 1
                        sum += int(readable[i]['Hum'])
                avg = sum / float(count)
                return avg
	def delete():
		from firebase import firebase
		firebase= firebase.FirebaseApplication('https://tempdata-4be31.firebaseio.com', None)
		result = firebase.delete('/Adatmentes', None)

	def timestamp():
		past = time.localtime(time.time()-60*60)
        	now = time.localtime(time.time())
		localtime = (time.strftime("%y/%m/%d %H:00:00", past) + "-" + time.strftime("%H:00:00", now))
		return localtime

	from firebase import firebase
	firebase= firebase.FirebaseApplication('https://tempdata-4be31.firebaseio.com', None)
	try:
		result = firebase.post('Adatelemzes', {'Time':str(timestamp()),'MinTemp':str(mintemp()),'MaxTemp':str(maxtemp()),'AvgTemp':str(avgtemp()),'MinHum':str(minhum()),'MaxHum':str(maxhum()),'AvgHum':str(avghum())})
	except:
		pass
	delete()
if __name__ == '__main__':
	main()
			
