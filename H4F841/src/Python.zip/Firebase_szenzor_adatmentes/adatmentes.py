#!/usr/bin/env python
# -*- coding:Utf-8 -*-

import os
import re
import time
import tosr0x
import math
import serial
import urllib2
import sys

def main():

    def currtemp():
        while True:
            try:
                temperature = urllib2.urlopen("http://192.168.1.4/meteograph.cgi?text=actual_th0_temp_c").read()
                break
            except:
                time.sleep(30)
        return temperature

    def currhum():
        while True:
            try:
                humidity = urllib2.urlopen("http://192.168.1.4/meteograph.cgi?text=actual_th0_hum_rel").read()
                break
            except:
                time.sleep(30)
        return humidity

    from firebase import firebase
    firebase= firebase.FirebaseApplication('https://tempdata-4be31.firebaseio.com', None)
	   
    while True:
        while True:
	    try:
                now = time.localtime(time.time())
                localtime = time.strftime("%y/%m/%d %H:%M:%S", now)
                result = firebase.post('Adatmentes', {'Time':str(localtime),'Temp':str(currtemp()),'Hum':str(currhum())})
	        break
	    except:
	        time.sleep(30)
        time.sleep(30)

if __name__ == '__main__':
	main()
