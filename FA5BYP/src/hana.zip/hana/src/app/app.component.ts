import { Component, OnInit } from '@angular/core';
import * as CanvasJS from 'canvasjs/canvasjs.min';
import { OdataService } from './services/odata.service';
import { dependenciesFromGlobalMetadata } from '@angular/compiler/src/render3/r3_factory';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent implements OnInit {
  title = 'Sap-Hana odata,';
  years :any = [];
  megyes :any = [];
  data;
  year : any;
  megye: any;

  data2;

  constructor(private odata: OdataService) { }

  ngOnInit() {

    this.year = 2017;
    this.megye= 'Budapest';


    this.odata.getData('/kalkulaciosodata?$select=ASZ_EVE').subscribe((res :any) => {
      for(let i = 0;i<res.d.results.length;++i)
      {
      this.years[i] = res.d.results[i].ASZ_EVE;
      }
    });

    this.odata.getData('/kalkulaciosodata?$select=MEGYE').subscribe((res :any) => {
      for(let i = 0;i<res.d.results.length;++i)
      {
      this.megyes[i] = res.d.results[i].MEGYE;
      }
    });

    this.odata.getData('cmegyeodata?').subscribe((res :any) => {
      this.data2 = res.d.results;
    });

    this.odata.getData('tablazatodata?$top=1000&$orderby=JEGYZ_TOKE_ERT_HUF+desc&distinct=true').subscribe((res :any) => {
      this.data = res.d.results;
      show_graph(this.data,this.data2);
    });

    function show_graph(db,db2) {

      var asd1 = [];
      var asd2 = [];

      for (var i = 0; i < db.length; ++i) {
        asd1.push({ label: db[i].TARS_ROV_NEV, y: db[i].JEGYZ_TOKE_ERT_HUF / 1000000 })
      }

      for(var i = 0; i< db2.length;++i)
      {
        asd2.push({ label: db2[i].MEGYE, y: db2[i].MENNYI})
      }
      console.log(asd2);

      var chart = new CanvasJS.Chart("chartContainer",
        {
          animationEnabled: true,
          exportEnabled: true,
          title: {
            text: "Cégek vagyona /millió forint",
            fontSize: 20
          },

          data: [
            {
              type: "column",
              indexLabelPlacement: "outside",
              indexLabelOrientation: "horizontal",
              dataPoints: asd1
            }
          ]
        });

        var chart = new CanvasJS.Chart("chartContainer2", {
          animationEnabled: true,
          title: {
            text: "Cégek száma megyénként (2017)"
          },
          data: [{
            type: "pie",
            startAngle: 240,
            //yValueFormatString: "##0.00'%'",
            indexLabel: "{label} {y}",
            dataPoints: asd2
          }]
        });
      chart.render();
    }
  }
  onChange(val) {

    if(isNaN(val))
    {
      this.megye = val;
    } else {
      this.year = val;
    } 
    
    var year2 = this.year;
    var megye2 = this.megye;

    var db = this.data;

         var newdb = db.filter(function (db) {
           return  db.ASZ_EVE == year2 && db.MEGYE == megye2;
       });

      var asd = [];

      for (var i = 0; i < newdb.length; ++i) {
        asd.push({ label: newdb[i].TARS_ROV_NEV, y: newdb[i].JEGYZ_TOKE_ERT_HUF / 1000000 })
      }

      var chart = new CanvasJS.Chart("chartContainer",
        {
          animationEnabled: true,
          exportEnabled: true,
          title: {
            text: "Cégek vagyona /millió forint",
            fontSize: 20
          },

          data: [
            {
              type: "column",
              indexLabelPlacement: "outside",
              indexLabelOrientation: "horizontal",
              dataPoints: asd
            }
          ]
        });
      chart.render();
  }
}



