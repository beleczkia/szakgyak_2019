import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class OdataService {
  constructor(private http: HttpClient) {   }
  
configUrl = '/hana/myodata.xsodata/';

/*getData(params) {
	console.log(params);
	const temp = params.join(',');
	return this.http.get(this.configUrl + param);
  //return this.http.get(this.configUrl + `&$select=${temp}`);
}
tablazatodata?$top=1000&$orderby=JEGYZ_TOKE_ERT_HUF+desc&distinct=true';
}*/

getData(params)
{
	return this.http.get(this.configUrl + params);
}
}
