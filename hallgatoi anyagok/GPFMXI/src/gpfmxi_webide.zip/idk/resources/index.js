var dataset = [2200, 167, 244, 116, 232, 185, 117, 150, 217, 124, 120, 63, 477,	1122, 156, 102, 43, 63, 150, 101, 21];
	
var svgWidth = 500, svgHeight = 300, barPadding = 5;
var barWidth = (svgWidth / dataset.length);

var svg = d3.select('svg')
	.attr("width", svgWidth)
	.attr("height", svgHeight);
	
var barChart = svg.selectAll("rect")
	.data(dataset)
	.enter()
	.append("rect")
	.attr("y", function(d) {
		return svgHeight - d;
	})
	.attr("height", function(d) {
		return d;
	})
	.attr("width", barWidth - barPadding)
	.attr("transform", function (d, i) {
		var translate = [barWidth * i, 0];
		return "translate(" + translate + ")";
	});